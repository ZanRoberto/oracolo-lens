"""
Sessions — memoria conversazionale AI (Narratore / Superrisponditore)
"""

from flask import Blueprint, request, jsonify
from models import db, AISession
from routes.auth import require_login

sessions_bp = Blueprint('sessions', __name__)


# ── GET /api/sessions?client_id=X&modulo=Y ──────────────────────────────────
@sessions_bp.route('/', methods=['GET'])
def get_session():
    user, err, code = require_login()
    if err: return err, code

    client_id = request.args.get('client_id', type=int)
    modulo    = request.args.get('modulo', 'platform')

    sess = AISession.query.filter_by(
        user_id   = user.id,
        client_id = client_id,
        modulo    = modulo
    ).order_by(AISession.updated_at.desc()).first()

    if not sess:
        return jsonify({'session': None}), 200

    return jsonify({'session': sess.to_dict()}), 200


# ── POST /api/sessions ────────────────────────────────────────────────────────
@sessions_bp.route('/', methods=['POST'])
def save_message():
    user, err, code = require_login()
    if err: return err, code

    data      = request.get_json() or {}
    client_id = data.get('client_id')
    modulo    = data.get('modulo', 'platform')
    role      = data.get('role')        # user | assistant
    content   = data.get('content', '')
    contesto  = data.get('contesto')    # snapshot dati azienda (opzionale)

    if role not in ('user', 'assistant'):
        return jsonify({'error': 'role deve essere user o assistant'}), 400

    sess = AISession.query.filter_by(
        user_id   = user.id,
        client_id = client_id,
        modulo    = modulo
    ).order_by(AISession.updated_at.desc()).first()

    if not sess:
        sess = AISession(
            user_id   = user.id,
            client_id = client_id,
            modulo    = modulo,
        )
        db.session.add(sess)

    if contesto:
        import json
        sess.contesto = json.dumps(contesto, ensure_ascii=False)

    sess.add_messaggio(role, content)
    db.session.commit()

    return jsonify({'ok': True, 'session_id': sess.id}), 200


# ── DELETE /api/sessions?client_id=X&modulo=Y ───────────────────────────────
@sessions_bp.route('/', methods=['DELETE'])
def clear_session():
    user, err, code = require_login()
    if err: return err, code

    client_id = request.args.get('client_id', type=int)
    modulo    = request.args.get('modulo', 'platform')

    AISession.query.filter_by(
        user_id   = user.id,
        client_id = client_id,
        modulo    = modulo
    ).delete()
    db.session.commit()

    return jsonify({'ok': True}), 200
