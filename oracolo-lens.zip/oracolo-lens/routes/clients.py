"""
Clients — aziende monitorate dal cliente licenziatario
"""

from flask import Blueprint, request, jsonify, session
from models import db, User, Client
from routes.auth import require_login

clients_bp = Blueprint('clients', __name__)


# ── GET /api/clients ─────────────────────────────────────────────────────────
@clients_bp.route('/', methods=['GET'])
def get_clients():
    user, err, code = require_login()
    if err: return err, code

    clients = Client.query.filter_by(user_id=user.id, attivo=True).all()
    return jsonify({'clients': [c.to_dict() for c in clients]}), 200


# ── GET /api/clients/<id> ────────────────────────────────────────────────────
@clients_bp.route('/<int:cid>', methods=['GET'])
def get_client(cid):
    user, err, code = require_login()
    if err: return err, code

    c = Client.query.filter_by(id=cid, user_id=user.id).first()
    if not c: return jsonify({'error': 'Azienda non trovata'}), 404
    return jsonify({'client': c.to_dict()}), 200


# ── POST /api/clients ────────────────────────────────────────────────────────
@clients_bp.route('/', methods=['POST'])
def create_client():
    user, err, code = require_login()
    if err: return err, code

    data = request.get_json() or {}
    if not data.get('nome'):
        return jsonify({'error': 'Nome azienda obbligatorio'}), 400

    c = Client(
        user_id = user.id,
        nome    = data['nome'],
        piva    = data.get('piva'),
        ateco   = data.get('ateco'),
        settore = data.get('settore'),
        citta   = data.get('citta'),
        rating  = data.get('rating'),
        rating_score = data.get('rating_score'),
    )
    if data.get('dati_finanziari'):
        c.set_dati(data['dati_finanziari'])

    db.session.add(c)
    db.session.commit()
    return jsonify({'ok': True, 'client': c.to_dict()}), 201


# ── PUT /api/clients/<id> ────────────────────────────────────────────────────
@clients_bp.route('/<int:cid>', methods=['PUT'])
def update_client(cid):
    user, err, code = require_login()
    if err: return err, code

    c = Client.query.filter_by(id=cid, user_id=user.id).first()
    if not c: return jsonify({'error': 'Azienda non trovata'}), 404

    data = request.get_json() or {}
    for field in ['nome', 'piva', 'ateco', 'settore', 'citta', 'rating', 'rating_score']:
        if field in data:
            setattr(c, field, data[field])
    if 'dati_finanziari' in data:
        c.set_dati(data['dati_finanziari'])

    db.session.commit()
    return jsonify({'ok': True, 'client': c.to_dict()}), 200


# ── DELETE /api/clients/<id> (soft delete) ───────────────────────────────────
@clients_bp.route('/<int:cid>', methods=['DELETE'])
def delete_client(cid):
    user, err, code = require_login()
    if err: return err, code

    c = Client.query.filter_by(id=cid, user_id=user.id).first()
    if not c: return jsonify({'error': 'Azienda non trovata'}), 404

    c.attivo = False
    db.session.commit()
    return jsonify({'ok': True}), 200
