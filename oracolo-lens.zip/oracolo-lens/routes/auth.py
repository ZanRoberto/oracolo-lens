"""
Auth — login, logout, profilo
"""

from flask import Blueprint, request, jsonify, session
from models import db, User

auth_bp = Blueprint('auth', __name__)


def require_login():
    uid = session.get('user_id')
    if not uid:
        return None, jsonify({'error': 'Non autenticato'}), 401
    user = User.query.get(uid)
    if not user:
        return None, jsonify({'error': 'Utente non trovato'}), 401
    return user, None, None


# ── POST /api/auth/login ─────────────────────────────────────────────────────
@auth_bp.route('/login', methods=['POST'])
def login():
    data  = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    pwd   = data.get('password', '')

    if not email or not pwd:
        return jsonify({'error': 'Email e password obbligatori'}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(pwd):
        return jsonify({'error': 'Credenziali non valide'}), 401

    if not user.piano_attivo:
        return jsonify({'error': 'Abbonamento scaduto — contattare Albaconsulting'}), 403

    session['user_id'] = user.id
    session.permanent  = True
    return jsonify({'ok': True, 'user': user.to_dict()}), 200


# ── POST /api/auth/logout ────────────────────────────────────────────────────
@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'ok': True}), 200


# ── GET /api/auth/me ─────────────────────────────────────────────────────────
@auth_bp.route('/me', methods=['GET'])
def me():
    user, err, code = require_login()
    if err:
        return err, code
    return jsonify({'user': user.to_dict()}), 200


# ── POST /api/auth/register (solo superadmin) ────────────────────────────────
@auth_bp.route('/register', methods=['POST'])
def register():
    # Solo un admin può creare nuovi utenti
    caller, err, code = require_login()
    if err:
        return err, code
    if not caller.is_admin:
        return jsonify({'error': 'Accesso negato'}), 403

    data  = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    pwd   = data.get('password', '')
    piano = data.get('piano', 'base')

    if not email or not pwd:
        return jsonify({'error': 'Email e password obbligatori'}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email già registrata'}), 409

    user = User(
        email   = email,
        nome    = data.get('nome', ''),
        societa = data.get('societa', ''),
        piano   = piano,
    )
    user.set_password(pwd)
    db.session.add(user)
    db.session.commit()
    return jsonify({'ok': True, 'user': user.to_dict()}), 201
